<?php 
include('config.php');
session_start();

function function_alert($message){
    echo "<script>alert('$message');</script>";
    }
    
if (isset($_POST['llogin'])){
    if (isset($_POST['email']) && isset($_POST['password'])) {
        function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
         }
            $email = validate($_POST['email']);
            $password = validate($_POST['password']);
    if (empty($email)) {
        header("Location: index.php?error=Username is required");
        exit();
    }
    else if(empty($password)){
        header("Location: index.php?error=Password is required");
    exit();
    }
    else{
        $sql = "SELECT * FROM td_users WHERE email ='$email' AND password ='$password'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            echo "Logged in!";
                $_SESSION['email'] = $row['email'];
                $_SESSION['previous'] = basename($_SERVER['PHP_SELF']);
                header("Location: homepage.php");
                exit();
                }
           
        else{
            header("Location: index.php?error=Incorrect Email or password");
            exit();
                }
        }
    }
    }
    else{
       
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aldrich&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,700&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Slab:300,400&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/Fixed-navbar-starting-with-transparency-styles.css">
    <link rel="stylesheet" href="assets/css/Fixed-navbar-starting-with-transparency-colors.css">
    <link rel="stylesheet" href="assets/css/Advanced-NavBar---Multi-dropdown.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-v2-Modal--Full-with-Google-Map.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Basic-icons.css">
    <link rel="stylesheet" href="assets/css/sticky-dark-top-nav-with-dropdown.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body>
    <div class="container">
        <div></div>
    </div>
    <nav class="navbar navbar-light navbar-expand-md navbar-fixed-top navigation-clean-button" style="width: 100%;background: #000000;">
        <div class="container">
            <div><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1" data-aos="fade" style="background: #fefefe;"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon" style="color: var(--bs-navbar-disabled-color);"></span></button></div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav nav-right">
                    <li class="nav-item"><a class="nav-link active" href="1111.html"><img src="assets/img/tech/logo1.jpg" width="72" height="64"></a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="#"><button class="btn btn-outline-primary" type="button" data-bs-toggle="modal" data-bs-target="#signup">Login</button></a></li>
                    <li class="nav-item"></li>
                </ul>
                <div class="modal fade" role="dialog" tabindex="-1" id="signup">
                    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                        <div class="modal-content">

                      
                            <div class="modal-header" style="border-color: rgb(0,0,0);color: rgb(0,0,0);">
                                <h4 style="border-color: rgb(0,0,0);font-weight: bold;">Sign In</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body" style="background: linear-gradient(rgb(39,39,39) 100%, #0b0b0b 100%, rgb(11,11,11) 100%);">
                                <form method="POST" action="index.php">
                                    <div class="form-group mb-3">
                                        <div class="input-group"><span class="text-primary input-group-text"><i class="fa fa-envelope-o"></i></span><input class="form-control" type="email" name="email" id="email" required="" placeholder="Email" style="font-weight: bold;"></div>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="input-group"><span class="text-primary input-group-text" style="width: 43.2969px;"><i class="fa fa-lock"></i></span><input class="form-control" type="password" name="password" id="password" required="" placeholder="Password" style="font-weight: bold;"></div>
                                        <?php if (isset($_GET['error'])) { ?>
                                        <p class="error"> <?php echo $_GET['error']; ?> </p>
                                        <?php }
                                        ?>
                                    </div>
                                    
                                    <div class="form-group mb-3"><button class="btn btn-primary btn-lg" style="width: 100%;" type="button" name="llogin" id="llogin">Login</button></div>
                                </form>
                                <hr style="background-color: #bababa;">
                                <p class="text-center">Or&nbsp;<a class="text-decoration-none" href="#">Forget password</a></p>
                                <p class="text-center">Don't have an account? &nbsp;<a class="text-decoration-none" href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#signin">Sign Up</a></p>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="modal fade" role="dialog" tabindex="-1" id="signin">
                    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header" style="color: rgb(0,0,0);">
                                <h4 style="font-weight: bold;">Sign Up Now</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body" style="background: linear-gradient(rgb(39,39,39) 99%, rgb(39,39,39) 100%, white 100%, black 100%, #0b0b0b 100%);">
                                <div class="text-center"></div>
                                <form class="mt-4" method="POST" action="index.php">
                                    <div class="form-group mb-3">
                                        <div class="input-group"><span class="text-primary input-group-text" style="width: 42.7188px;"><i class="fa fa-user-o"></i></span><input class="form-control" type="text" id="fname" required="" placeholder="Full Name" style="font-weight: bold;"></div>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="input-group"><span class="text-primary input-group-text"><i class="fa fa-envelope-o"></i></span><input class="form-control" type="email" id="email1" required="" placeholder="Email" style="font-weight: bold;"></div>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="input-group"><span class="text-primary input-group-text" style="width: 42.2969px;"><i class="fa fa-lock"></i></span><input class="form-control" type="password" id="password1" required="" placeholder="Password" style="font-weight: bold;"></div>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="form-check"><input class="form-check-input" type="checkbox" id="formCheck-1" required="" checked=""><label class="form-check-label" for="formCheck-1">I agree all the terms and conditions.</label></div>
                                    </div>
                                    <div class="form-group mb-3"><button class="btn btn-primary btn-lg" style="width: 100%;" type="button">Sign Up</button></div>
                                </form>
                                <hr style="background-color: #bababa;">
                                <p class="text-center">Already have an Account?&nbsp;<a class="text-decoration-none" href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#signup">Log In</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <section style="background: url(&quot;assets/img/gifB.gif&quot;);height: 540.391px;">
        <div class="container" style="height: 550.391px;">
            <div>
                <h1 style="font-family: Aldrich, sans-serif;color: rgb(255,255,255);font-size: 52px;height: 54.3906px;"><br></h1>
                <h1 style="color: rgb(255,255,255);font-family: Aldrich, sans-serif;margin-top: 144px;font-size: 72px;font-weight: bold;">Welcome to CrypTech!</h1>
            </div>
        </div>
    </section>
    <footer class="page-footer dark" style="padding-top: 0px;">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <h5>Get started</h5>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Sign up</a></li>
                        <li><a href="#">Downloads</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5>About us</h5>
                    <ul>
                        <li><a href="#">Company Information</a></li>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">Reviews</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5>Support</h5>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Help desk</a></li>
                        <li><a href="#">Forums</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5>Legal</h5>
                    <ul>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <p>© 2022 Copyright Text</p>
        </div>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.11.1/baguetteBox.min.js"></script>
    <script src="assets/js/vanilla-zoom.js"></script>
    <script src="assets/js/theme.js"></script>
    <script src="assets/js/Advanced-NavBar---Multi-dropdown.js"></script>
    <script src="assets/js/Bootstrap-4---Payment-Form.js"></script>
    <script src="assets/js/Contact-Form-v2-Modal--Full-with-Google-Map.js"></script>
    <script src="assets/js/Fixed-navbar-starting-with-transparency.js"></script>
</body>

</html>