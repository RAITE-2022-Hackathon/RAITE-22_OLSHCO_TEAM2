1. extract the files to the htdocs.
2. open your xampp and create a database name it "crypto".
3. import the database.odb inside to the database named "cyrpto"
4. open the index in your chrome